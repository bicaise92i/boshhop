<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{leoproductsearch}prestashop>leoproductsearch_78f9aa1218f71a20d84b4d719030f44f'] = 'Recherche rapide de produits par bloc de catégorie';
$_MODULE['<{leoproductsearch}prestashop>leoproductsearch_da80ebe916ef5d16126e76660d38b193'] = 'Ajoute un champ de recherche rapide de produits à votre site Web.';
$_MODULE['<{leoproductsearch}prestashop>leosearch_13348442cc6a27032d2b4aa28b75a5d3'] = 'Chercher';
$_MODULE['<{leoproductsearch}prestashop>leosearch_ce1b00a24b52e74de46971b174d2aaa6'] = 'Recherche de produits:';
$_MODULE['<{leoproductsearch}prestashop>leosearch_a6a2a55bea8760389dfca77132905b7c'] = 'Toutes catégories';
$_MODULE['<{leoproductsearch}prestashop>leosearch_top_13348442cc6a27032d2b4aa28b75a5d3'] = 'Chercher';
$_MODULE['<{leoproductsearch}prestashop>leosearch_top_ce1b00a24b52e74de46971b174d2aaa6'] = 'Recherche de produits:';
$_MODULE['<{leoproductsearch}prestashop>leosearch_top_a6a2a55bea8760389dfca77132905b7c'] = 'Toutes catégories';
$_MODULE['<{leoproductsearch}prestashop>productsearch_13348442cc6a27032d2b4aa28b75a5d3'] = 'Chercher';
$_MODULE['<{leoproductsearch}prestashop>search_13348442cc6a27032d2b4aa28b75a5d3'] = 'Chercher';
$_MODULE['<{leoproductsearch}prestashop>search_05cf990f79d935b0ea6105855adef686'] = 'Retournez à la page précédente';
$_MODULE['<{leoproductsearch}prestashop>search_3a93aed43691aed28d2ce3a53d3c63f8'] = '%d résultat a été trouvé.';
$_MODULE['<{leoproductsearch}prestashop>search_a09e4037d02313230a191007246e1694'] = '%d résultats ont été trouvés.';
$_MODULE['<{leoproductsearch}prestashop>search_b2c56c8b57680e576c61c1b5df0d0c2d'] = 'Aucun résultat n\'a été trouvé pour votre recherche';
$_MODULE['<{leoproductsearch}prestashop>search_a4bb6bf91165c149d73930f43ad4ef69'] = 'Veuillez saisir un mot-clé de recherche';
